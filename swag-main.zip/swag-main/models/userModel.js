const mongoose = require('mongoose')

let currentDate = new Date();
        let newDate = new Date(currentDate.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
        let formattedDate = newDate.toISOString();

const userSchema = new mongoose.Schema({
    phone: {
        type: String,
        required: true,
        index: true,
        unique: [true, 'Phone number already exists'],
      },
    fullname: {
        type: String,
        required: true,
        trim: true,
        maxlength: 25
    },
    username: {
        type: String,
        required: true,
        trim: true,
        maxlength: 25,
        unique: true
    },
    email: {
        type: String,
        trim: true,
    },
    password: {
        type: String,
        required: true
    },
    otp:{
        type:String,
    },
    avatar:{
        type: String,
        default: 'https://res.cloudinary.com/devatchannel/image/upload/v1602752402/avatar/avatar_cugq40.png'
    },
    coverImg:{
        type:String,
        default:null
    },
    role: {type: String, default: 'user'},
    gender: {type: String, default: 'male'},
    location: {
        type: { type: String,enum: ['Point'], default: 'Point' },
        coordinates: { type: [Number], required: true },
      },
    fcmToken:{type:String},
    Biostory: {
        type: String, 
        default: '',
        maxlength: 200
    },
    website: {type: String, default: ''},
    followers: [{type: mongoose.Types.ObjectId, ref: 'user'}],
    blockUser: [{type: mongoose.Types.ObjectId, ref: 'user'}],
    following: [{type: mongoose.Types.ObjectId, ref: 'user'}],
    saved: [{type: mongoose.Types.ObjectId, ref: 'user'}],
    story:[{
        storyId:{type: mongoose.Types.ObjectId},
        image:{type:String , required: true},
        date: { type : Date, default: Date.now }
    }],
    createdAt: {
        type: Date,
        required: true,
        default: formattedDate
     },
    updatedAt: {
        type: Date,
        required: true,
        default: formattedDate
     },
}, {
    timestamps: false
})


userSchema.index({ location: '2dsphere' });


module.exports = mongoose.model('user', userSchema)