const mongoose = require('mongoose')
        let currentDate = new Date();
        let newDate = new Date(currentDate.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
        let formattedDate = newDate.toISOString();
const messageSchema = new mongoose.Schema({
    conversation: { type: mongoose.Types.ObjectId, ref: 'conversation' },
    sender: { type: mongoose.Types.ObjectId, ref: 'user' },
    recipient: { type: mongoose.Types.ObjectId, ref: 'user' },
    type: String,
    text: String,
    url:String,
    media: Array,
    call: Object,
    isSeen:{
        type:Number,
        default:0
    },
    createdAt: {
        type: Date,
        required: true,
        default: Date.now
     },
    updatedAt: {
        type: Date,
        required: true,
        default: Date.now
     },
}, {
    timestamps: false
})

module.exports = mongoose.model('message', messageSchema)