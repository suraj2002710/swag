const mongoose = require('mongoose')
const momenttimezone = require('moment-timezone');
momenttimezone.tz.setDefault('Asia/Kolkata');






const postSchema = new mongoose.Schema({
    content: String,
    images: {
        type: Array,
    },
    postType:{
        type:String,
    },
    video: {
        type: String,
    },
    audio:{
        type:String,
    },
    hashTags:[{type:String}],
    likes: [{ type: mongoose.Types.ObjectId, ref: 'user' }],
    comments: [{ type: mongoose.Types.ObjectId, ref: 'comment' }],
    user: {type: mongoose.Types.ObjectId, ref: 'user'},
    location:{type:String},
    createdAt: {
        type: Date,
        required: true,
        default: Date.now
     },
    updatedAt: {
        type: Date,
        required: true,
        default: Date.now
     },
},{
    timestamps:false
})

module.exports = mongoose.model('post', postSchema)