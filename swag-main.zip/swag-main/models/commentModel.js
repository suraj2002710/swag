const mongoose = require('mongoose')
let currentDate = new Date();
        let newDate = new Date(currentDate.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
        let formattedDate = newDate.toISOString();
const commentSchema = new mongoose.Schema({
    content: {
        type: String,
        required: true
    },
    tag: {type: mongoose.Types.ObjectId, ref: 'user'},
    reply:{type:mongoose.Types.ObjectId , ref:'comment'},
    likes: [{type: mongoose.Types.ObjectId, ref: 'user'}],
    user: {type: mongoose.Types.ObjectId, ref: 'user'},
    postId: mongoose.Types.ObjectId,
    postUserId: mongoose.Types.ObjectId,
    createdAt: {
        type: Date,
        required: true,
        default: currentDate
     },
    updatedAt: {
        type: Date,
        required: true,
        default: currentDate
     },
}, {
    timestamps: false
})

module.exports = mongoose.model('comment', commentSchema)