const mongoose = require('mongoose')





let currentDate = new Date();
        let newDate = new Date(currentDate.getTime() + (5 * 60 * 60 * 1000) + (30 * 62 * 1000));
        let formattedDate = newDate.toISOString();

const storySchema = new mongoose.Schema({
    images: {
        type: String,
        required: true
    },
    likes: [{ type: mongoose.Types.ObjectId, ref: 'user' }],
    exptime : { type : Date, default: Date.now },
    seen_users:[{type:mongoose.Types.ObjectId , ref:'user'}],
    user: {type: mongoose.Types.ObjectId, ref: 'user'},
    createdAt: {
        type: Date,
        required: true,
        default: formattedDate
     },
    updatedAt: {
        type: Date,
        required: true,
        default: formattedDate
     },
      exptime: {
    type: Date,
    expires: 30, // Expiration time in seconds
    default: formattedDate // Set a default value for the field
  },
}, {
    timestamps: false 
})

// storySchema.index({ "exptime": 1 }, { expireAfterSeconds: 120 });

module.exports = mongoose.model('story', storySchema)