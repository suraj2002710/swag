const mongoose = require('mongoose')







let currentDate = new Date();
        let newDate = new Date(currentDate.getTime() + (5 * 60 * 60 * 1000) + (30 * 62 * 1000));
        let formattedDate = newDate.toISOString();

const storyUserSchema = new mongoose.Schema({
    user: {type: mongoose.Types.ObjectId, ref: 'user'},
    completeseen: [{type:mongoose.Types.ObjectId , ref:'user'}],
    exptime : { type : Date, default: Date.now },
    laststory: mongoose.Types.ObjectId,
    createdAt: {
        type: Date,
        required: true,
        default: formattedDate
     },
    updatedAt: {
        type: Date,
        required: true,
        default: formattedDate
     },
      exptime: {
    type: Date,
    expires: 30, // Expiration time in seconds
    default: formattedDate // Set a default value for the field
  },
}, {
    timestamps: false
})

// storyUserSchema.index({ "exptime": 1 }, { expireAfterSeconds:120 }); // 3600 = 1 hour 
// mongo runs the process every 60sec
// after each expireAfterSeconds change drop the collection to make it work
 
module.exports = mongoose.model('storyUser', storyUserSchema)