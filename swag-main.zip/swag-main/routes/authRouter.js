const Router = require('express').Router()
const authCtrl = require('../controllers/authCtrl')

// router.post('/register', authCtrl.register)

// router.post('/login', authCtrl.login)

// router.post('/logout', authCtrl.logout)

// router.post('/refresh_token', authCtrl.generateAccessToken)





Router.post('/sendOtp', authCtrl.sendOtp);
Router.post('/forgotPassOtp', authCtrl.forgotPassOtp )
Router.post('/verifyOtp', authCtrl.verifyOtp);
Router.post('/register', authCtrl.register);
Router.post('/updatePass', authCtrl.updatePassword)
Router.post('/login', authCtrl.login);
Router.post('/logout', authCtrl.logout);
Router.post('/loginwithotp',authCtrl.loginWithotp)




module.exports = Router