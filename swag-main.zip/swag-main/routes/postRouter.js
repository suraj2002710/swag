const router = require('express').Router()
const postCtrl = require('../controllers/postCtrl')
const reelCtrl = require('../controllers/reelCtrl')
const auth = require('../middleware/auth')




const multer = require('multer');

var Storage = multer.diskStorage({
    destination: "uploads",
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now())
    }
});

var upload = multer({ storage: Storage })

router.route('/posts')
    .post(auth  , upload.any() , postCtrl.createPost)
    .get(auth, postCtrl.getPosts)

router.route('/reels')
    .post(auth, reelCtrl.createReel)
    .get(auth, reelCtrl.getReels)


router.route('/post/:id')
    .patch(auth, postCtrl.updatePost)
    .get(auth, postCtrl.getPost)
    .delete(auth, postCtrl.deletePost)

router.patch('/post/:id/like', auth, postCtrl.likePost)

router.get('/nearby-post/:location' , auth , postCtrl.getNearbyPost)
router.get('/trending-post' , auth , postCtrl.getTrendingPost)


router.patch('/post/:id/unlike', auth, postCtrl.unLikePost)

router.get('/user_posts/:id', auth, postCtrl.getUserPosts)

router.get('/hashtag_post/:hashtag', auth, postCtrl.getTagPosts)

router.get('/user_reels/:id', auth, reelCtrl.getUserReel)

router.get('/post_discover', auth, postCtrl.getPostsDicover)

router.patch('/savePost/:id', auth, postCtrl.savePost)

router.patch('/unSavePost/:id', auth, postCtrl.unSavePost)

router.get('/getSavePosts', auth, postCtrl.getSavePosts)


module.exports = router