const Posts = require('../models/postModel')
const Comments = require('../models/commentModel')
const Users = require('../models/userModel')
const { sendFireBaseNOtificationFCM } = require('../fcmNotification');
const moment = require('moment');
const momenttimezone = require('moment-timezone');
momenttimezone.tz.setDefault('Asia/Kolkata');

const { uploadFile, uploadVideo } = require("../s3")

const AWS_folder = "post/"


class APIfeatures {
    constructor(query, queryString) {
        this.query = query;
        this.queryString = queryString;
    }

    paginating() {
        const page = this.queryString.page * 1 || 1
        const limit = this.queryString.limit * 1 || 10
        const skip = (page - 1) * limit
        this.query = this.query.skip(skip).limit(limit)
        return this;
    }
}

const postCtrl = {
    createPost: async (req, res) => {
        // try {
        // console.error(moment(Date.now()).format('YYYY-MM-DDTHH:mm:ss.SSSZ'))
        let currentDate = new Date();
        let newDate = new Date(currentDate.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
        let formattedDate = newDate.toISOString();
        const { hashTags, content, postType, location } = req.body

        // if (req.files.length === 0)
        //     return res.status(400).json({ msg: "Please add your photo." })
        const newPost = new Posts({
            hashTags, postType, content, user: req.user._id, location ,createdAt: formattedDate  })
        await newPost.save()
        let uploadResult
        if (req.files) {
            // console.log(req.files)
            for (i = 0; i < req.files.length; i++) {
                const file = req.files[i]
                uploadResult = await uploadFile(file, AWS_folder)
                //console.log("img", uploadResult)
                newPost.images.push(uploadResult.Location)
            }
        }

        await newPost.save()

        res.json({
            msg: 'Created Post!',
            newPost: {
                ...newPost._doc,
                user: req.user
            }
        })
        // } catch (err) {
        //     return res.status(500).json({msg: err.message})
        // }
    },
    getPosts: async (req, res) => {
        // try {
            const saved_post = await Users.findById({ _id: req.user._id },'saved')
  
            const features = new APIfeatures(Posts.find({
                user: [...req.user.following, req.user._id], postType: "post",
                hashTags:[],
            }), req.query).paginating()

            const posts = await features.query.sort('-createdAt')
                .populate("user", "avatar username fullname followers")
                .populate({
                    path: "comments",
                    populate: {
                        path: "user ",
                        select: "-password"
                    }
                })
    

                const total_documents = await Posts.find({
                user: [...req.user.following, req.user._id], postType: "post",
                hashTags:[],
            }).countDocuments();

            res.json({
                msg: 'Success!',
                result: total_documents,
                posts,
                saved:saved_post.saved
            })

        // } catch (err) {
        //     return res.status(500).json({ msg: err.message })
        // }
    },
    getNearbyPost: async (req, res) => {
        try {
            const saved_post = await Users.findById({ _id: req.user._id },'saved')
  
            const features = new APIfeatures(Posts.find({
                user: [...req.user.following, req.user._id], postType: "post", location: req.params.location
            }), req.query).paginating()

            const posts = await features.query.sort('-createdAt')
                .populate("user", "avatar username fullname followers")
                .populate({
                    path: "comments",
                    populate: {
                        path: "user",
                        select: "-password"
                    }
                })
 const total_documents = await Posts.find({
                user: [...req.user.following, req.user._id], postType: "post", location: req.params.location
            }).countDocuments();
            res.json({
                msg: 'Success!',
                result: total_documents,
                posts,
                saved:saved_post.saved
            })
        } catch (error) {

        }
    },
    getTrendingPost: async (req, res) => {
        // try {
            const saved_post = await Users.findById({ _id: req.user._id },'saved')
            const leaderboardUser = await Users.find({
                _id:{$nin:[req.user._id]},
                location:
                {
                    $near:
                    {
                        $geometry: req.user.location,
                        $minDistance: 0,
                        $maxDistance: 25
                    }
                }
            }).distinct('_id');
            
            const features = new APIfeatures(Posts.aggregate( [
                { "$unwind": "$user" }, 
                { $match: {
                    'user': { $ne: req.user._id }, postType: "post",
                    user:{$in: leaderboardUser},
                    likes:{$not:{$size: 0}}
                }
            },
            {
                $lookup: {
                    from: 'users',
                    localField: 'user',
                    foreignField: '_id',
                    as: 'user'
                }
            },
                { $addFields: { arrSize: { $size: "$likes" } } },
                { $sort: { arrSize: -1 } },
                {
                    "$project": {
                      "_id": 1,
                      "images": 1,
                      "hashTags": 1,
                      "likes": 1,
                      "comments": 1,
                      "postType": 1,
                      "content": 1,
                      "user._id": 1,
                      "user.avatar": 1,
                      "user.fullname": 1,
                      "user.username": 1,
                      "location": 1,
                      "createdAt": 1,
                      "updatedAt": 1,
                      "__v": 1,
                      "arrSize": 1,
                    }
                  }
              ] ), req.query).paginating()

            const posts = await features.query //adds a new field, to the existing ones (incl. _id)
            
                // .populate("user", "avatar username fullname followers")
                // .populate({
                //     path: "comments",
                //     populate: {
                //         path: "user",
                //         select: "-password"
                //     }
                // })
 const total_documents = await Posts.aggregate( [
            { "$unwind": "$user" }, 
            { $match: {
                'user': { $ne: req.user._id }, postType: "post",
                user:{$in: leaderboardUser},
                likes:{$not:{$size: 0}}
            }
        }]);
            res.json({
                msg: 'Success!',
                result: total_documents.length,
                posts,
                leaderboardUser,
                saved:saved_post.saved
            })
        // } catch (error) {

        // }
    },
    getTagPosts: async (req, res) => {
        try {
            const saved_post = await Users.findById({ _id: req.user._id },'saved')
  
            const features = new APIfeatures(Posts.find({
                hashTags: req.params.hashtag
            }), req.query).paginating()

            const posts = await features.query.sort('-createdAt')
                .populate("user", "avatar username fullname followers")
                .populate({
                    path: "comments",
                    populate: {
                        path: "user",
                        select: "-password"
                    }
                })
            res.json({
                msg: 'Success!',
                result: posts.length,
                posts,
                saved:saved_post.saved
            })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    updatePost: async (req, res) => {
        try {
            const { content, images, hashTags } = req.body

            const post = await Posts.findOneAndUpdate({ _id: req.params.id }, {
                content, images,
                $push: { hashTags: hashTags }
            }).populate("user", "avatar username fullname")
                .populate({
                    path: "comments",
                    populate: {
                        path: "user",
                        select: "-password"
                    }
                })

            res.json({
                msg: "Updated Post!",
                newPost: {
                    ...post._doc,
                    content, images
                }
            })
        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    likePost: async (req, res) => {
        try {
            const post = await Posts.find({ _id: req.params.id, likes: req.user._id });

            // if (post.length > 0) return res.status(400).json({ msg: "You already liked this post." })

            const like = await Posts.findOneAndUpdate({ _id: req.params.id }, {
                $push: { likes: req.user._id }
            }, { new: true }).populate("user",['_id likes']).populate('user')

            if (!like) return res.status(400).json({ msg: 'This post does not exist.' })
            if(JSON.stringify(like.user._id) !== JSON.stringify(req.user._id) ){
            sendFireBaseNOtificationFCM([like.user?.fcmToken],'Post liked', req.user.fullname+' like your post',like.user, req.user)
            }
            res.json({ msg: 'Liked Post!' })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    unLikePost: async (req, res) => {
        try {

            const like = await Posts.findOneAndUpdate({ _id: req.params.id }, {
                $pull: { likes: req.user._id }
            }, { new: true })

            if (!like) return res.status(400).json({ msg: 'This post does not exist.' })

            res.json({ msg: 'UnLiked Post!' })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    getUserPosts: async (req, res) => {
        try {
            const features = new APIfeatures(Posts.find({ user: req.params.id, postType: 'post' }), req.query)
                .paginating()
            const posts = await features.query.sort("-createdAt")
const total_documents = await Posts.find({ user: req.params.id, postType: 'post' }).countDocuments();
            res.json({
                posts,
                result: total_documents
            })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    getPost: async (req, res) => {
        try {
            const post = await Posts.findById(req.params.id)
                .populate("user ", "avatar username fullname followers")
                .populate({
                    path: "comments",
                    populate: {
                        path: "user ",
                        select: "-password"
                    }
                })

            if (!post) return res.status(400).json({ msg: 'This post does not exist.' })

            res.json({
                post
            })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    getPostsDicover: async (req, res) => {
        try {

            const newArr = [...req.user.following, req.user._id]
            console.log(newArr)
            const num = req.query.num || 9

            const posts = await Posts.aggregate([
                { $match: { user: { $nin: newArr } } },
                { $sample: { size: Number(num) } },
                { $lookup: {
                        from: "users",
                        localField: "user",
                        foreignField: "_id",
                        as: "user"
                    }
                },
                {$unwind: '$user'}
            ])

            return res.json({
                msg: 'Success!',
                result: posts.length,
                posts
            })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    deletePost: async (req, res) => {
        try {
            const post = await Posts.findOneAndDelete({ _id: req.params.id, user: req.user._id })
            await Comments.deleteMany({ _id: { $in: post.comments } })

            res.json({
                msg: 'Deleted Post!',
                newPost: {
                    ...post,
                    user: req.user
                }
            })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    savePost: async (req, res) => {
        try {
            const user = await Users.find({ _id: req.user._id, saved: req.params.id })
            if (user.length > 0) return res.status(400).json({ msg: "You saved this post." })

            const save = await Users.findOneAndUpdate({ _id: req.user._id }, {
                $push: { saved: req.params.id }
            }, { new: true })

            if (!save) return res.status(400).json({ msg: 'This user does not exist.' })

            res.json({ msg: 'Saved Post!' })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    unSavePost: async (req, res) => {
        try {
            const save = await Users.findOneAndUpdate({ _id: req.user._id }, {
                $pull: { saved: req.params.id }
            }, { new: true })

            if (!save) return res.status(400).json({ msg: 'This user does not exist.' })

            res.json({ msg: 'unSaved Post!' })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
    getSavePosts: async (req, res) => {
        try {
            const features = new APIfeatures(Posts.find({
                _id: { $in: req.user.saved }
            }), req.query).paginating()

            const savePosts = await features.query.sort("-createdAt")

            res.json({
                savePosts,
                result: savePosts.length
            })

        } catch (err) {
            return res.status(500).json({ msg: err.message })
        }
    },
}

module.exports = postCtrl