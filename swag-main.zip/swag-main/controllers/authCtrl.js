// const Users = require("../models/userModel");
// const bcrypt = require("bcrypt");
// const jwt = require("jsonwebtoken");

// const authCtrl = {

// register: async (req, res) => {
//     try {
//         const { fullname, username, email, password, gender } = req.body
//         let newUserName = username.toLowerCase().replace(/ /g, '')

//         const user_name = await Users.findOne({username: newUserName})
//         if(user_name) return res.status(400).json({msg: "This user name already exists."})

//         const user_email = await Users.findOne({email})
//         if(user_email) return res.status(400).json({msg: "This email already exists."})

//         if(password.length < 6)
//         return res.status(400).json({msg: "Password must be at least 6 characters."})

//         const passwordHash = await bcrypt.hash(password, 12)

//         const newUser = new Users({
//             fullname, username: newUserName, email, password: passwordHash, gender
//         })

//         const access_token = createAccessToken({id: newUser._id})
//         const refresh_token = createRefreshToken({id: newUser._id})

//         res.cookie('refreshtoken', refresh_token, {
//             httpOnly: true,
//             path: '/api/refresh_token',
//             maxAge: 30*24*60*60*1000 // 30days
//         })

//         await newUser.save()

//         res.json({
//             msg: 'Register Success!',
//             access_token,
//             user: {
//                 ...newUser._doc,
//                 password: ''
//             }
//         })
//     } catch (err) {
//         return res.status(500).json({msg: err.message})
//     }
// },

//   register: async (req, res) => {
//     try {
//       const { phone, name, username, password } = req.body;
//       if (!name || !username || !password) {
//         return res
//           .status(400)
//           .json({ msg: "Please enter all credentials required" });
//       }
//       if (password.length < 6)
//         return res
//           .status(400)
//           .json({ msg: "Password must be at least 6 characters." });
//       const isAlreadyVerified = await VerModel.findOne({ phone });
//       console.log(isAlreadyVerified);
//       if (!isAlreadyVerified || !isAlreadyVerified.isVerified) {
//         return res
//           .status(401)
//           .json({ msg: "Phone number not verified please try again" });
//       }

//       const isPhoneExist = await User.findOne({ phone });
//       if (isPhoneExist) {
//         return res.status(401).json({
//           msg: "Phone number already exist please try with different phone number",
//         });
//       }
//       const isUserNameExist = await User.findOne({ username });
//       if (isUserNameExist) {
//         return res.status(401).json({
//           msg: "UserName already exist please try with different UserName",
//         });
//       }
//       const passwordHash = await bcrypt.hash(password, 12);
//       const saveData = await User.create({
//         name,
//         username,
//         password: passwordHash,
//         phone,
//       });

//       res.status(201).json({ msg: "User registered successfully" });
//     } catch (error) {
//       console.log(error);
//       res.status(500).send({ error: error.message });
//     }
//   },

//   login: async (req, res) => {
//     try {
//       const { email, password } = req.body;

//       const user = await Users.findOne({ email }).populate(
//         "followers following",
//         "avatar username fullname followers following"
//       );

//       if (!user)
//         return res.status(400).json({ msg: "This email does not exist." });

//       const isMatch = await bcrypt.compare(password, user.password);
//       if (!isMatch)
//         return res.status(400).json({ msg: "Password is incorrect." });

//       const access_token = createAccessToken({ id: user._id });
//       const refresh_token = createRefreshToken({ id: user._id });

//       res.cookie("refreshtoken", refresh_token, {
//         httpOnly: true,
//         path: "/api/refresh_token",
//         maxAge: 30 * 24 * 60 * 60 * 1000, // 30days
//       });

//       res.json({
//         msg: "Login Success!",
//         access_token,
//         user: {
//           ...user._doc,
//           password: "",
//         },
//       });
//     } catch (err) {
//       return res.status(500).json({ msg: err.message });
//     }
//   },
//   logout: async (req, res) => {
//     try {
//       res.clearCookie("refreshtoken", { path: "/api/refresh_token" });
//       return res.json({ msg: "Logged out!" });
//     } catch (err) {
//       return res.status(500).json({ msg: err.message });
//     }
//   },
//   generateAccessToken: async (req, res) => {
//     try {
//       const rf_token = req.cookies.refreshtoken;
//       if (!rf_token) return res.status(400).json({ msg: "Please login now." });

//       jwt.verify(
//         rf_token,
//         process.env.REFRESH_TOKEN_SECRET,
//         async (err, result) => {
//           if (err) return res.status(400).json({ msg: "Please login now." });

//           const user = await Users.findById(result.id)
//             .select("-password")
//             .populate(
//               "followers following",
//               "avatar username fullname followers following"
//             );

//           if (!user)
//             return res.status(400).json({ msg: "This does not exist." });

//           const access_token = createAccessToken({ id: result.id });

//           res.json({
//             access_token,
//             user,
//           });
//         }
//       );
//     } catch (err) {
//       return res.status(500).json({ msg: err.message });
//     }
//   },
// };

// const createAccessToken = (payload) => {
//   return jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET, {
//     expiresIn: "1d",
//   });
// };

// const createRefreshToken = (payload) => {
//   return jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET, {
//     expiresIn: "30d",
//   });
// };

// module.exports = authCtrl;





















const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const twilio = require("twilio");

const User = require("../models/userModel.js");
const VerModel = require("../models/verification.js");
const dotenv = require("dotenv");
dotenv.config();

const accountSid = process.env.ACCOUNT_SID;
const authToken = process.env.AUTH_TOKEN;
const serviceId = process.env.SERVICE_ID;
const client = twilio(accountSid, authToken);

const authCtrl = {
  // sendOtp: async (req, res) => {
  //   try {
  //     const phone = req.body.phone;
  //     if (!phone) {
  //       return res.status(404).json({ msg: "Please enter a phone number" });
  //     }
  //     const user = await User.findOne({ phone });
  //     if (user) {
  //       return res.json({ msg: "This number already registered" });
  //     }

  //     const findNum = await VerModel.findOne({phone:phone})

  //     client.verify
  //       .services(serviceId)
  //       .verifications.create({ to: phone, channel: "sms" })
  //       .then((verification) => {
  //         console.log({ verification });
  //       })
  //       .catch((error) => {
  //          return res.json({ error });
  //       });

  //     if(findNum){
  //       return res.json({ msg: "OTP send Successfully Again" });
  //     }
  //     else{
  //     const saveData = await VerModel.create({ phone });
  //     return res.json({ msg: "OTP send Successfully" });
  //     }


  //   } catch (error) {
  //     console.log("catch error" ,error);
  //     return res.send({ msg: "Please enter phone number again" });
  //   }
  // },
  sendOtp: async (req, res) => {
    try {
      const phone = req.body.phone;
      if (!phone) {
        return res.status(404).json({ msg: "Please enter a phone number" });
      }
      const user = await User.findOne({ phone });
      if (user) {
        return res.json({ msg: "This number already registered" });
      }

      // Twilio Send Otp Code
      client.verify
        .services(serviceId)
        .verifications.create({ to: phone, channel: "sms" })
        .then((verification) => {
          res.status(200).json({ verification });
        })
        .catch((error) => {
          return res.status(400).json({ error });
        });

      const saveData = await VerModel.findOneAndUpdate({ phone }, {
        phone: phone
      },
        { new: true, upsert: true });
      return res.status(200).json({ msg: "OTP send Successfully", otp: "1234" });

    } catch (error) {
      console.log("catch error", error);
      return res.send({ msg: "Please enter phone number again" });
    }
  },
  forgotPassOtp: async (req, res) => {
    try {
      const phone = req.body.phone;

      if (!phone) {
        return res.status(404).json({ msg: "Please enter a phone number" });
      }
      const user = await User.findOne({ phone });
      if (!user) {
        return res.json({ msg: "This number is not registered" });
      }

      client.verify
        .services(serviceId)
        .verifications.create({ to: phone, channel: "sms" })
        .then((verification) => {
          res.status(200).json({ verification });
        })
        .catch((error) => {
          res.status(400).json({ error });
        });

      return res.status(200).json({ msg: "OTP send Successfully" });
    } catch (error) {
      console.log(error);
      return res.status(500).send({ msg: "Please enter phone number again" });
    }
  },

  verifyOtp: async (req, res) => {
    try {
      const { phone, code } = req.body;

      //Verify OTP code
      client.verify
        .services(serviceId)
        .verificationChecks.create({ to: phone, code: code })
        .then(async (verification_check) => {
          if(verification_check.valid){
                  await VerModel.updateOne({ phone }, { $set: { isVerified: true } });
          return res.status(200).json({verification:"Otp verified"})
          }else{
                return res.status(201).json({verification:"Invalid Otp"})
          }
      
        })
        .catch((error) => {
            console.log(error)
          return res.status(201).json({ error });
        });

      //Below code is temporary
      // await VerModel.updateOne({ phone }, { $set: { isVerified: true } });
      // if(code=='1234'){
        // return res.status(200).json({verification:"Otp verified"})
      // }
    } catch (error) {
      console.log(error);
      return res.status(500).send({ msg: "Please enter phone number again" });
    }
  },

  register: async (req, res) => {
    try {
        // let currentDate = new Date();
        // let newDate = new Date(currentDate.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
        // let formattedDate = newDate.toISOString();
      const { phone, fullname, username, password } = req.body;
      if (!fullname || !username || !password) {
        return res
          .status(400)
          .json({ msg: "Please enter all credentials required" });
      }

      if (password.length < 6)
        return res
          .status(400)
          .json({ msg: "Password must be at least 6 characters." });

      const isAlreadyVerified = await VerModel.findOne({ phone });
      console.log(isAlreadyVerified);
      // if (!isAlreadyVerified || !isAlreadyVerified.isVerified) {
      //   return res
      //     .status(401)
      //     .json({ msg: "Phone number not verified please try again" });
      // }

      const isPhoneExist = await User.findOne({ phone });

      if (isPhoneExist) {
        return res.status(401).json({
          msg: "Phone number already exist please try with different phone number",
        });
      }

      const isUserNameExist = await User.findOne({ username });
      if (isUserNameExist) {
        return res.status(401).json({
          msg: "UserName already exist please try with different UserName",
        });
      }

      const passwordHash = await bcrypt.hash(password, 12);
      const saveData = await User.create({ fullname, username, password: passwordHash, phone,
        location: { type: "Point", coordinates: ['75', '27'] }
       });

      res.status(201).json({ msg: "User registered successfully" });
    } catch (error) {
      console.log(error);
      res.status(500).send({ error: error.message });
    }
  },

  updatePassword: async (req, res) => {
    try {
      const { phone, code, password } = req.body
      const passwordHash = await bcrypt.hash(password, 12);
      client.verify
        .services(serviceId)
        .verificationChecks.create({ to: phone,from:"+9115263971" ,code: code })
        .then(async (verification_check) => {
          await User.findOneAndUpdate(
            { phone: phone },
            {
              password: passwordHash
            }
          )
          return res.status(200).json({ msg: 'Password Changed Successfully' });
        })
        .catch((error) => {
          return res.status(400).json({ error });
        });

    } catch (error) {
      res.status(500).send({ error: error.message });
    }
  },

  login: async (req, res) => {
    try {
      const { phone, username, password } = req.body;
      if (phone) {
        if (!password) {
          return res
            .status(400)
            .json({ msg: "Please enter all credentials required" });
        }
        console.error(phone,'phone')
        const userData = await User.findOne({ phone });
        if (!userData) {
          return res.status(400).json({ msg: "Credentials invalid" });
        }
        // if (password !== userData.password) {
        //   return res.status(400).json({ msg: "Credentials invalid" });
        // }

        const isMatch = await bcrypt.compare(password, userData.password);
        if (!isMatch)
          return res.status(400).json({ msg: "Password is incorrect." });

        const access_token = createAccessToken({ id: userData._id });

        res.status(200).json({
          message: "user logged in",
          access_token,
          user: userData,
        });
      } else {
        if (!password) {
          return res
            .status(400)
            .json({ msg: "Please enter all credentials required" });
        }
        const userData = await User.findOne({ username });
        if (!userData) {
          return res.status(400).json({ msg: "Credentials invalid" });
        }
        const isMatch = await bcrypt.compare(password, userData.password);
        if (!isMatch)
          return res.status(400).json({ msg: "Password is incorrect." });

        const access_token = createAccessToken({ id: userData._id });
        const refresh_token = createRefreshToken({ id: userData._id });

        res.cookie("refreshtoken", refresh_token, {
          httpOnly: true,
          path: "/api/refresh_token",
          maxAge: 30 * 24 * 60 * 60 * 1000, // 30days
        });

        res.json({
          msg: "Login Success!",
          access_token,
          user: userData
        });

      }
    } catch (error) {
      console.log(error);
      res.status(500).send({ error: error.message });
    }
  },

  logout: async (req, res) => {
    try {
      res.clearCookie("refreshtoken", { path: "/api/refresh_token" });
      return res.json({ msg: "Logged out!" });
    } catch (err) {
      return res.status(500).json({ msg: err.message });
    }
  },

  generateAccessToken: async (req, res) => {
    try {
      const rf_token = req.cookies.refreshtoken;
      if (!rf_token) return res.status(400).json({ msg: "Please login now." });

      jwt.verify(
        rf_token,
        process.env.REFRESH_TOKEN_SECRET,
        async (err, result) => {
          if (err) return res.status(400).json({ msg: "Please login now." });

          const user = await User.findById(result.id)
            .select("-password")
            .populate(
              "followers following",
              "avatar username fullname followers following"
            );

          if (!user)
            return res.status(400).json({ msg: "This does not exist." });

          const access_token = createAccessToken({ id: result.id });

          res.json({
            access_token,
            user,
          });
        }
      );
    } catch (err) {
      return res.status(500).json({ msg: err.message });
    }
  },
  loginWithotp:async(req,res)=>{
    try {
      
        const {phone,key}=req.body
        const finddata=await User.findOne({phone:phone})
        console.log(finddata);
        let otp= Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000;
        if(finddata){
              const updateotp=await User.updateOne({phone:phone},{$set:{otp:otp}})
              if(updateotp){
                
                client.verify
                .services(serviceId)
                .verifications.create({ to: phone,from:"+9115263971",body:`your otp ${otp} ${key}`, code:key,channel: "sms" })
                .then((verification) => {
                  res.status(200).json({ verification });
                })
                .catch((error) => {
                  return res.status(400).json({ error });
                });
              }
        }else{
          return res.status(400).json({ msg:"user not exit" });
        }
    
    } catch (error) {
        return res.status(500).json({ msg: err.message })
    }
}
};

const createAccessToken = (payload) => {
  return jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET, {
    expiresIn: "30d",
  });
};

const createRefreshToken = (payload) => {
  return jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET, {
    expiresIn: "30d",
  });
};

module.exports = authCtrl;
