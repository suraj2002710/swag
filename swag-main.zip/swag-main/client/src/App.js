import logo from './logo.svg';
import './App.css';
import {io} from 'socket.io-client'
import { useEffect , useState} from 'react';







function App() {
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    const newSocket = io();
    newSocket.on('connect', (socket) => {
      console.log('socket connected', socket);
    })
    
    setSocket(newSocket);
    return () => newSocket.close();
  }, [setSocket]);
  
  return (
    <div className="App">
      hello
    </div>
  );
}

export default App;
